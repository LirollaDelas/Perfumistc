// Função para retornar o resultado com base nos botões selecionados
function calcularResultado(botaoId1, botaoId2) {
    // Lógica para calcular o resultado com base nos IDs dos botões selecionados
    // Este é um exemplo simples, você pode substituir isso pela sua lógica real
    if (botaoId1 === "botao1" && botaoId2 === "botao2") {
        return 1;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao3") {
        return 2;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao4") {
        return 3;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao5") {
        return 4;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao6") {
        return 5;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao7") {
        return 6;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao8") {
        return 7;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao9") {
        return 8;
    } else if (botaoId1 === "botao1" && botaoId2 === "botao10") {
        return 9;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao1") {
        return 10;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao3") {
        return 11;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao4") {
        return 12;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao5") {
        return 13;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao6") {
        return 14;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao7") {
        return 15;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao8") {
        return 16;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao9") {
        return 17;
    } else if (botaoId1 === "botao2" && botaoId2 === "botao10") {
        return 18;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao1") {
        return 19;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao2") {
        return 20;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao4") {
        return 21;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao5") {
        return 22;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao6") {
        return 23;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao7") {
        return 24;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao8") {
        return 25;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao9") {
        return 26;
    } else if (botaoId1 === "botao3" && botaoId2 === "botao10") {
        return 27;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao1") {
        return 28;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao2") {
        return 29;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao3") {
        return 30;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao5") {
        return 31;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao6") {
        return 32;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao7") {
        return 33;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao8") {
        return 34;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao9") {
        return 35;
    } else if (botaoId1 === "botao4" && botaoId2 === "botao10") {
        return 36;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao1") {
        return 37;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao2") {
        return 38;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao3") {
        return 39;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao4") {
        return 40;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao6") {
        return 41;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao7") {
        return 42;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao8") {
        return 43;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao9") {
        return 44;
    } else if (botaoId1 === "botao5" && botaoId2 === "botao10") {
        return 45;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao1") {
        return 46;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao2") {
        return 47;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao3") {
        return 48;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao4") {
        return 49;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao5") {
        return 50;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao6") {
        return 51;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao7") {
        return 52;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao8") {
        return 53;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao9") {
        return 54;
    } else if (botaoId1 === "botao6" && botaoId2 === "botao10") {
        return 55;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao1") {
        return 56;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao2") {
        return 57;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao3") {
        return 58;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao4") {
        return 59;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao5") {
        return 60;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao6") {
        return 61;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao7") {
        return 62;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao8") {
        return 63;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao9") {
        return 64;
    } else if (botaoId1 === "botao7" && botaoId2 === "botao10") {
        return 65;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao1") {
        return 66;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao2") {
        return 67;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao3") {
        return 68;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao4") {
        return 69;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao5") {
        return 70;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao6") {
        return 71;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao7") {
        return 72;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao8") {
        return 73;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao9") {
        return 74;
    } else if (botaoId1 === "botao8" && botaoId2 === "botao10") {
        return 75;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao1") {
        return 76;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao2") {
        return 77;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao3") {
        return 78;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao4") {
        return 79;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao5") {
        return 80;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao6") {
        return 81;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao7") {
        return 82;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao8") {
        return 83;
    } else if (botaoId1 === "botao9" && botaoId2 === "botao10") {
        return 84;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao1") {
        return 85;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao2") {
        return 86;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao3") {
        return 87;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao4") {
        return 88;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao5") {
        return 89;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao6") {
        return 90;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao7") {
        return 91;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao8") {
        return 92;
    } else if (botaoId1 === "botao10" && botaoId2 === "botao9") {
        return 93;
    }
    var resultado = calcularResultado(botaoId1, botaoId2);
window.location.href = "pagina_de_resultado.html?resultado=" + resultado;
}
    // Adicione mais lógica conforme necessário para os outros resultados
    // Se nenhum caso corresponder, retorne um resultado padrão ou undefined

// Variáveis para rastrear os botões selecionados
let botaoSelecionado1 = null;
let botaoSelecionado2 = null;

// Função para verificar se ambos os botões estão selecionados e calcular o resultado
function verificarSelecao() {
    if (botaoSelecionado1 !== null && botaoSelecionado2 !== null) {
        // Calcula o resultado com base nos botões selecionados
        const resultado = calcularResultado(botaoSelecionado1.id, botaoSelecionado2.id);
        if (resultado !== undefined) {
            // Redireciona para a página de resultado com base no resultado calculado
            window.location.href = "pagina_de_resultado.html?resultado=" + resultado;
        } else {
            // Exibe uma mensagem de erro se nenhum resultado for encontrado
            alert("Nenhum resultado encontrado para esta combinação de botões.");
        }
    }
}
// Adiciona o evento de clique a todos os botões
document.querySelectorAll('.botao').forEach(function(botao) {
    botao.addEventListener("click", function() {
        // Se ambos os botões já estiverem selecionados, não faça nada
        if (botaoSelecionado1 !== null && botaoSelecionado2 !== null) {
            return;
        }
        // Verifica qual botão está selecionado
        if (botaoSelecionado1 === null) {
            botaoSelecionado1 = botao;
        } else if (botaoSelecionado1 !== botao) {
            botaoSelecionado2 = botao;
        }
        // Adiciona uma classe para indicar visualmente que o botão está selecionado
        botao.classList.add("selecionado");
        // Verifica se ambos os botões estão selecionados e calcula o resultado
        verificarSelecao();
    });
});
