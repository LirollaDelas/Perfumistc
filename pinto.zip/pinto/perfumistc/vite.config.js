function mostrarResultado(botao) {
  // Verifica qual botão foi clicado e exibe um resultado correspondente
  var resultado = document.getElementById("resultado");
  if (botao === 'Botão 1') {
      resultado.textContent = "Você clicou no Botão 1!";
  } else if (botao === 'Botão 2') {
      resultado.textContent = "Você clicou no Botão 2!";
  }
}
export default {
  // Configurações do Vite
};